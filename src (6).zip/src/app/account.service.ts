import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  url:string='http://localhost:8080/accountdetails/';

  constructor(private http:HttpClient) { }
  findAccountByAcN(acc_number:string)
  {
    return this.http.get(this.url+acc_number);
  }
  updateBalance(acc_number:String,amount:any){
    return this.http.put(this.url+acc_number+"/"+amount+"/",null);


  }
}

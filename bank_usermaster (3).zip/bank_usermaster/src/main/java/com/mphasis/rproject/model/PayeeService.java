package com.mphasis.rproject.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.rproject.entity.Payee;
import com.mphasis.rproject.entity.User;
@Component("ps")
public class PayeeService {
	@Autowired
	PayeeRepo payeeRepo;
	public Payee create(Payee payee) {
		return payeeRepo.save(payee);
	}
	public List<Payee> read() {
		return payeeRepo.findAll();
	}
	public Payee read(String payeeId) 
	{
		return payeeRepo.findById(payeeId).get();
	}
	

	public Payee update(Payee payee) {
		return payeeRepo.save(payee);
	}
	public void delete(String payeeId) {
		Payee payee = payeeRepo.findById(payeeId).get();
		payeeRepo.delete(payee);
	}

}

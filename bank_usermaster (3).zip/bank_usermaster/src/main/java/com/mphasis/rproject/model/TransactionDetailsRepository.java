package com.mphasis.rproject.model;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;

import com.mphasis.rproject.entity.TransactionDetails;

@Repository
public interface TransactionDetailsRepository extends JpaRepository<TransactionDetails, Long>{

//	@Query("update AccountDetails ad set ad.balance=ad.balance-")

	
	

}

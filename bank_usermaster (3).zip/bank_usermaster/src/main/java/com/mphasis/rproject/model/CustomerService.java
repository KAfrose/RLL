package com.mphasis.rproject.model;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.mphasis.rproject.entity.Customer;
import com.mphasis.rproject.model.CustomerRepository;

@Component("cs")
public class CustomerService 
{
	@Autowired
	CustomerRepository customerRepository;
	public Customer create(Customer customer) {
		return customerRepository.save(customer);
	}
	public List<Customer> read() {
		return customerRepository.findAll();
	}
	
	public Customer update(Customer customer) {
		return customerRepository.save(customer);
	}
	public void delete(String customerId) {
		Customer customer = customerRepository.findById(customerId).get();
		customerRepository.delete(customer);
	}

}

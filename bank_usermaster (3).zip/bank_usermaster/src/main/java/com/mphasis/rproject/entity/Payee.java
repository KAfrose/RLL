package com.mphasis.rproject.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PAYEE")
public class Payee {
	@Id
	private String payeeId;
	private String payeeName;
	private String bankName;
	private String acc_number;
	private String userName;
	public Payee() {}
	public Payee(String payeeId, String payeeName, String bankName, String acc_number, String userName) {
		super();
		this.payeeId = payeeId;
		this.payeeName = payeeName;
		this.bankName = bankName;
		this.acc_number = acc_number;
		this.userName = userName;
	}
	public String getPayeeId() {
		return payeeId;
	}
	public void setPayeeId(String payeeId) {
		this.payeeId = payeeId;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public String getAcc_number() {
		return acc_number;
	}
	public void setAcc_number(String acc_number) {
		this.acc_number = acc_number;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "Payee [payeeId=" + payeeId + ", payeeName=" + payeeName + ", bankName=" + bankName + ", acc_number="
				+ acc_number + ", userName=" + userName + "]";
	}
	
	

}

